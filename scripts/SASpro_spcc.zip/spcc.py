# pro/spcc.py
# Spectroscopic Photometric Color Calibration (SPCC) for SASpro
# Uses Gaia DR3 XP spectra for accurate color calibration
# Standalone script version with full GUI - matches sfcc.py workflow

from __future__ import annotations

import os
import sys
import numpy as np

from PyQt6.QtCore import Qt, QSettings, QStandardPaths
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox,
    QSpinBox, QDoubleSpinBox, QCheckBox, QGroupBox, QGridLayout,
    QProgressBar, QMessageBox, QApplication, QDialog
)

# ─────────────────────────────────────────────────────────────────────────────
# Lazy loading of optional dependencies (only when actually used)
# ─────────────────────────────────────────────────────────────────────────────

# Cache for lazy-loaded modules
_lazy_cache = {}

def _get_sep():
    """Lazy load SEP."""
    if 'sep' not in _lazy_cache:
        try:
            import sep
            _lazy_cache['sep'] = sep
        except ImportError:
            _lazy_cache['sep'] = None
    return _lazy_cache['sep']

def _get_astropy():
    """Lazy load astropy components."""
    if 'astropy' not in _lazy_cache:
        try:
            from astropy.io import fits
            from astropy.wcs import WCS
            from astropy.coordinates import SkyCoord
            import astropy.units as u
            _lazy_cache['astropy'] = {
                'fits': fits, 'WCS': WCS, 'SkyCoord': SkyCoord, 'u': u
            }
        except ImportError:
            _lazy_cache['astropy'] = None
    return _lazy_cache['astropy']

def _get_vizier():
    """Lazy load VizieR."""
    if 'vizier' not in _lazy_cache:
        try:
            from astroquery.vizier import Vizier
            _lazy_cache['vizier'] = Vizier
        except ImportError:
            _lazy_cache['vizier'] = None
    return _lazy_cache['vizier']

def _get_gaiaxpy():
    """Lazy load GaiaXPy."""
    if 'gaiaxpy' not in _lazy_cache:
        try:
            from gaiaxpy import calibrate as gaiaxpy_calibrate
            _lazy_cache['gaiaxpy'] = gaiaxpy_calibrate
        except ImportError:
            _lazy_cache['gaiaxpy'] = None
    return _lazy_cache['gaiaxpy']

def _get_gaia_downloader():
    """Lazy load gaia_downloader module from scripts/spcc/ subdirectory."""
    if 'gaia_downloader' not in _lazy_cache:
        result = {'available': False, 'GaiaSpectraDB': None, 'GaiaDownloader': None,
                  'CalibratedSpectrum': None, 'GaiaSource': None}

        # Only location: scripts/spcc subdirectory relative to spcc.py
        script_dir = os.path.dirname(os.path.abspath(__file__))
        spcc_subdir = os.path.join(script_dir, "spcc")

        if os.path.exists(spcc_subdir) and spcc_subdir not in sys.path:
            sys.path.insert(0, spcc_subdir)

        try:
            from gaia_downloader import GaiaSpectraDB, GaiaDownloader, CalibratedSpectrum, GaiaSource
            result = {
                'available': True,
                'GaiaSpectraDB': GaiaSpectraDB,
                'GaiaDownloader': GaiaDownloader,
                'CalibratedSpectrum': CalibratedSpectrum,
                'GaiaSource': GaiaSource
            }
        except ImportError:
            pass

        _lazy_cache['gaia_downloader'] = result
    return _lazy_cache['gaia_downloader']

def _get_matplotlib():
    """Lazy load matplotlib."""
    if 'matplotlib' not in _lazy_cache:
        try:
            from matplotlib.figure import Figure
            from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
            _lazy_cache['matplotlib'] = {'Figure': Figure, 'FigureCanvas': FigureCanvas}
        except ImportError:
            try:
                from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
                from matplotlib.figure import Figure
                _lazy_cache['matplotlib'] = {'Figure': Figure, 'FigureCanvas': FigureCanvas}
            except ImportError:
                _lazy_cache['matplotlib'] = None
    return _lazy_cache['matplotlib']


# ─────────────────────────────────────────────────────────────────────────────
# Availability Check Functions
# ─────────────────────────────────────────────────────────────────────────────

def _is_astropy_available():
    return _get_astropy() is not None

def _is_sep_available():
    return _get_sep() is not None

def _is_matplotlib_available():
    return _get_matplotlib() is not None

def _is_gaiaxpy_available():
    return _get_gaiaxpy() is not None

def _is_local_db_available():
    gd = _get_gaia_downloader()
    return gd is not None and gd.get('available', False)


# ─────────────────────────────────────────────────────────────────────────────
# Utilities
# ─────────────────────────────────────────────────────────────────────────────

def _ensure_angstrom(wl: np.ndarray) -> np.ndarray:
    """If wavelengths look like nm, convert to Angstrom."""
    med = float(np.median(wl))
    return wl * 10.0 if 250.0 <= med <= 2000.0 else wl


def find_sasp_data_path() -> str | None:
    """Find the SASP data file (SASP_data.fits) in common locations."""
    user_home = os.path.expanduser("~")
    base_dirs = [
        os.path.join(user_home, "setiastrosuitepro"),
        os.path.dirname(__file__),
        os.path.join(user_home, ".sasp"),
        user_home,
        QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppDataLocation),
    ]

    candidates = []
    for base in base_dirs:
        if not base:
            continue
        candidates.append(os.path.join(base, "src", "setiastro", "data", "SASP_data.fits"))
        candidates.append(os.path.join(base, "SASP_data.fits"))
        candidates.append(os.path.join(base, "data", "SASP_data.fits"))

    script_dir = os.path.dirname(__file__)
    for i in range(5):
        candidates.append(os.path.join(script_dir, "SASP_data.fits"))
        candidates.append(os.path.join(script_dir, "data", "SASP_data.fits"))
        script_dir = os.path.dirname(script_dir)

    for path in candidates:
        if os.path.exists(path):
            return path
    return None


def ensure_user_custom_fits() -> str:
    """Ensure user custom curves file exists."""
    # Check in standard app data location
    app_data_base = os.path.join(os.path.expanduser("~"), "AppData", "Roaming",
                                  "SetiAstro", "Seti Astro Suite Pro")
    known_path = os.path.join(app_data_base, "usercustomcurves.fits")
    if os.path.exists(known_path):
        return known_path

    app_data = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppDataLocation)
    os.makedirs(app_data, exist_ok=True)
    path = os.path.join(app_data, "usercustomcurves.fits")
    if not os.path.exists(path):
        astropy = _get_astropy()
        if astropy:
            fits = astropy['fits']
            fits.HDUList([fits.PrimaryHDU()]).writeto(path)
    return path


def get_local_gaia_db_path() -> str | None:
    """Get path for local Gaia spectra database (scripts/spcc/ only)."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    spcc_subdir = os.path.join(script_dir, "spcc")
    db_path = os.path.join(spcc_subdir, "gaia_spectra.db")
    if os.path.exists(db_path):
        return db_path
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Main Dialog
# ─────────────────────────────────────────────────────────────────────────────

class SPCCDialog(QDialog):
    """Spectroscopic Photometric Color Calibration Dialog for SASpro scripts."""

    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.setWindowTitle("Spectroscopic Photometric Color Calibration (SPCC)")
        self.setMinimumSize(900, 600)

        # Data paths
        self.sasp_data_path = find_sasp_data_path()
        self.user_custom_path = ensure_user_custom_fits() if _is_astropy_available() else None

        # Lists for combos
        self.sed_list = []
        self.filter_list = []
        self.sensor_list = []

        # State
        self.image: np.ndarray | None = None
        self.header: dict | None = None
        self.wcs = None
        self.star_list = []
        self.field_center = None
        self.field_radius_deg = 0

        # Load filter/sensor/SED lists
        if _is_astropy_available():
            self._reload_hdu_lists()

        self._build_ui()
        self._load_settings()
        self._connect_signals()
        self._load_from_ctx()

    def _reload_hdu_lists(self):
        """Load filter, sensor, and SED lists from FITS files."""
        self.sed_list = []
        self.filter_list = []
        self.sensor_list = []

        astropy = _get_astropy()
        if not astropy:
            return
        fits = astropy['fits']

        for path in [self.sasp_data_path, self.user_custom_path]:
            if not path or not os.path.exists(path):
                continue
            try:
                with fits.open(path, mode="readonly", memmap=False) as hdul:
                    for hdu in hdul:
                        if isinstance(hdu, fits.BinTableHDU):
                            ctype = hdu.header.get("CTYPE", "").upper()
                            extname = hdu.header.get("EXTNAME", "")
                            if ctype == "SED" and extname not in self.sed_list:
                                self.sed_list.append(extname)
                            elif ctype == "FILTER" and extname not in self.filter_list:
                                self.filter_list.append(extname)
                            elif ctype == "SENSOR" and extname not in self.sensor_list:
                                self.sensor_list.append(extname)
            except Exception as e:
                print(f"[SPCC] Error loading {path}: {e}")

        self.sed_list.sort()
        self.filter_list.sort()
        self.sensor_list.sort()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        # Row 1: Fetch stars, DB options, star limit
        row1 = QHBoxLayout()
        layout.addLayout(row1)

        self.fetch_stars_btn = QPushButton("Step 1: Fetch Gaia Stars")
        f = self.fetch_stars_btn.font()
        f.setBold(True)
        self.fetch_stars_btn.setFont(f)
        self.fetch_stars_btn.clicked.connect(self._fetch_stars)
        row1.addWidget(self.fetch_stars_btn)

        local_db_avail = _is_local_db_available()
        self.use_local_db_chk = QCheckBox("Use Local DB")
        self.use_local_db_chk.setChecked(local_db_avail)
        self.use_local_db_chk.setEnabled(local_db_avail)
        row1.addWidget(self.use_local_db_chk)

        self.save_to_local_db_chk = QCheckBox("Save to DB")
        self.save_to_local_db_chk.setChecked(local_db_avail)
        self.save_to_local_db_chk.setEnabled(local_db_avail)
        row1.addWidget(self.save_to_local_db_chk)

        row1.addWidget(QLabel("Star Limit:"))
        self.star_limit_combo = QComboBox()
        self.star_limit_combo.addItems(["25", "50", "75", "100", "150", "200", "300", "500", "750", "1000", "2000", "All"])
        self.star_limit_combo.setCurrentText("200")
        row1.addWidget(self.star_limit_combo)

        row1.addSpacing(20)
        row1.addWidget(QLabel("White Reference:"))
        self.star_combo = QComboBox()
        # Note: PyQt6 addItem() requires userData as positional arg, not keyword
        self.star_combo.addItem("Vega (A0V)", "A0V")
        for sed in self.sed_list:
            if sed.upper() != "A0V":
                self.star_combo.addItem(sed, sed)
        row1.addWidget(self.star_combo)

        idx_g2v = self.star_combo.findData("G2V")
        if idx_g2v >= 0:
            self.star_combo.setCurrentIndex(idx_g2v)

        # Row 2: RGB Filter selection
        row2 = QHBoxLayout()
        layout.addLayout(row2)

        row2.addWidget(QLabel("R Filter:"))
        self.r_filter_combo = QComboBox()
        self.r_filter_combo.addItem("(None)")
        self.r_filter_combo.addItems(self.filter_list)
        row2.addWidget(self.r_filter_combo)

        row2.addSpacing(20)
        row2.addWidget(QLabel("G Filter:"))
        self.g_filter_combo = QComboBox()
        self.g_filter_combo.addItem("(None)")
        self.g_filter_combo.addItems(self.filter_list)
        row2.addWidget(self.g_filter_combo)

        row2.addSpacing(20)
        row2.addWidget(QLabel("B Filter:"))
        self.b_filter_combo = QComboBox()
        self.b_filter_combo.addItem("(None)")
        self.b_filter_combo.addItems(self.filter_list)
        row2.addWidget(self.b_filter_combo)

        row2.addStretch()

        # Row 3: Sensor and LP filters
        row3 = QHBoxLayout()
        layout.addLayout(row3)

        row3.addStretch()
        row3.addWidget(QLabel("Sensor (QE):"))
        self.sens_combo = QComboBox()
        self.sens_combo.addItem("(None)")
        self.sens_combo.addItems(self.sensor_list)
        row3.addWidget(self.sens_combo)

        row3.addSpacing(20)
        row3.addWidget(QLabel("LP/Cut Filter1:"))
        self.lp_filter_combo = QComboBox()
        self.lp_filter_combo.addItem("(None)")
        self.lp_filter_combo.addItems(self.filter_list)
        row3.addWidget(self.lp_filter_combo)

        row3.addSpacing(20)
        row3.addWidget(QLabel("LP/Cut Filter2:"))
        self.lp_filter_combo2 = QComboBox()
        self.lp_filter_combo2.addItem("(None)")
        self.lp_filter_combo2.addItems(self.filter_list)
        row3.addWidget(self.lp_filter_combo2)

        row3.addStretch()

        # Row 4: Run calibration, options
        row4 = QHBoxLayout()
        layout.addLayout(row4)

        self.run_btn = QPushButton("Step 2: Run Color Calibration")
        f2 = self.run_btn.font()
        f2.setBold(True)
        self.run_btn.setFont(f2)
        self.run_btn.clicked.connect(self._run_calibration)
        self.run_btn.setEnabled(False)
        row4.addWidget(self.run_btn)

        self.bg_neutral_chk = QCheckBox("Background Neutralization")
        self.bg_neutral_chk.setChecked(True)
        row4.addWidget(self.bg_neutral_chk)

        row4.addSpacing(15)
        row4.addWidget(QLabel("Star detect σ:"))
        self.sep_thr_spin = QSpinBox()
        self.sep_thr_spin.setRange(2, 50)
        self.sep_thr_spin.setValue(5)
        row4.addWidget(self.sep_thr_spin)

        row4.addStretch()

        # Advanced Settings
        self.advanced_group = QGroupBox("Advanced Photometry Settings")
        self.advanced_group.setCheckable(True)
        self.advanced_group.setChecked(False)
        adv_layout = QGridLayout(self.advanced_group)

        adv_layout.addWidget(QLabel("Aperture (px):"), 0, 0)
        self.aperture_spin = QSpinBox()
        self.aperture_spin.setRange(3, 20)
        self.aperture_spin.setValue(8)
        self.aperture_spin.setToolTip(
            "Radius in pixels for star flux measurement.\n"
            "Larger values capture more light but include more background noise.\n"
            "Should be large enough to contain most of the star's PSF.")
        adv_layout.addWidget(self.aperture_spin, 0, 1)

        adv_layout.addWidget(QLabel("BG inner:"), 0, 2)
        self.bg_inner_spin = QSpinBox()
        self.bg_inner_spin.setRange(5, 30)
        self.bg_inner_spin.setValue(12)
        self.bg_inner_spin.setToolTip(
            "Inner radius of the background annulus in pixels.\n"
            "The annulus is a ring-shaped region around each star used to\n"
            "measure the local sky background level, which is then subtracted\n"
            "from the star's flux. Should be larger than aperture to avoid star light.")
        adv_layout.addWidget(self.bg_inner_spin, 0, 3)

        adv_layout.addWidget(QLabel("BG outer:"), 0, 4)
        self.bg_outer_spin = QSpinBox()
        self.bg_outer_spin.setRange(10, 50)
        self.bg_outer_spin.setValue(18)
        self.bg_outer_spin.setToolTip(
            "Outer radius of the background annulus in pixels.\n"
            "Together with BG inner, defines the ring where sky background is sampled.\n"
            "A larger ring provides more pixels for a robust background estimate,\n"
            "but may include neighboring stars or gradients in crowded fields.")
        adv_layout.addWidget(self.bg_outer_spin, 0, 5)

        adv_layout.addWidget(QLabel("SNR threshold:"), 1, 0)
        self.snr_spin = QDoubleSpinBox()
        self.snr_spin.setRange(1.0, 50.0)
        self.snr_spin.setValue(5.0)
        self.snr_spin.setToolTip(
            "Minimum signal-to-noise ratio required for a star to be used.\n"
            "Stars with SNR below this threshold are rejected.\n"
            "Higher values = fewer but more reliable stars.")
        adv_layout.addWidget(self.snr_spin, 1, 1)

        adv_layout.addWidget(QLabel("Saturation:"), 1, 2)
        self.sat_spin = QDoubleSpinBox()
        self.sat_spin.setRange(0.5, 1.0)
        self.sat_spin.setValue(0.95)
        self.sat_spin.setDecimals(2)
        self.sat_spin.setToolTip(
            "Maximum pixel value (0-1 normalized) before a star is considered saturated.\n"
            "Saturated stars have clipped flux and incorrect color ratios.\n"
            "Lower values are more conservative (reject more stars).")
        adv_layout.addWidget(self.sat_spin, 1, 3)

        adv_layout.addWidget(QLabel("Sigma clip:"), 1, 4)
        self.sigma_spin = QDoubleSpinBox()
        self.sigma_spin.setRange(1.0, 5.0)
        self.sigma_spin.setValue(2.5)
        self.sigma_spin.setToolTip(
            "Number of standard deviations for outlier rejection.\n"
            "Used in background estimation and color matrix fitting.\n"
            "Lower values = more aggressive rejection of outliers.")
        adv_layout.addWidget(self.sigma_spin, 1, 5)

        # Row 2: Matrix fitting controls
        self.use_full_matrix_chk = QCheckBox("Use full 3×3 matrix")
        self.use_full_matrix_chk.setChecked(True)
        self.use_full_matrix_chk.setToolTip(
            "When enabled, fits a full 3×3 color correction matrix that accounts\n"
            "for cross-channel color contamination. When disabled, uses a simpler\n"
            "diagonal matrix (independent R/G/B scaling) which is more stable but\n"
            "less accurate for cameras with significant channel crosstalk.")
        adv_layout.addWidget(self.use_full_matrix_chk, 2, 0, 1, 2)

        adv_layout.addWidget(QLabel("Min stars for 3×3:"), 2, 2)
        self.min_stars_3x3_spin = QSpinBox()
        self.min_stars_3x3_spin.setRange(5, 100)
        self.min_stars_3x3_spin.setValue(15)
        self.min_stars_3x3_spin.setToolTip(
            "Minimum number of stars required to use the full 3×3 matrix.\n"
            "If fewer stars pass quality filters, the algorithm falls back to\n"
            "diagonal-only mode for numerical stability.\n"
            "Higher values = more conservative (requires more stars for 3×3).")
        adv_layout.addWidget(self.min_stars_3x3_spin, 2, 3)

        self.force_3x3_chk = QCheckBox("Force 3×3")
        self.force_3x3_chk.setChecked(False)
        self.force_3x3_chk.setToolTip(
            "Force use of full 3×3 matrix regardless of condition number.\n"
            "Normally the algorithm falls back to diagonal-only if the matrix\n"
            "condition number is too high (>50). Enable this to always use\n"
            "full 3×3 correction even with high condition numbers.")
        adv_layout.addWidget(self.force_3x3_chk, 2, 4)

        adv_layout.addWidget(QLabel("Regularization:"), 2, 5)
        self.reg_spin = QDoubleSpinBox()
        self.reg_spin.setRange(0.1, 100.0)
        self.reg_spin.setValue(1.0)
        self.reg_spin.setSingleStep(0.5)
        self.reg_spin.setDecimals(1)
        self.reg_spin.setToolTip(
            "Regularization toward identity matrix.\n"
            "Higher values push the 3×3 matrix toward identity (slopes → 1.0).\n"
            "Lower values allow more cross-channel correction (tighter scatter).\n"
            "1.0 = default, try 10-50 if AFTER slopes deviate from 1.0.")
        adv_layout.addWidget(self.reg_spin, 2, 6)

        # Connect checkbox to enable/disable the controls
        self.use_full_matrix_chk.toggled.connect(self.min_stars_3x3_spin.setEnabled)
        self.use_full_matrix_chk.toggled.connect(self.force_3x3_chk.setEnabled)
        self.use_full_matrix_chk.toggled.connect(self.reg_spin.setEnabled)

        layout.addWidget(self.advanced_group)

        # Matplotlib canvas for plots (BP-RP histogram and calibration diagnostics)
        mpl = _get_matplotlib()
        if mpl:
            self.figure = mpl['Figure'](figsize=(14, 3.6), dpi=100)  # 20% shorter
            self.canvas = mpl['FigureCanvas'](self.figure)
            self.canvas.setMinimumHeight(256)  # 320 * 0.8 = 256
            self.canvas.setVisible(False)  # Hidden until stars are fetched
            layout.addWidget(self.canvas)

        # Progress and status
        self.status_label = QLabel("Load an image to begin")
        layout.addWidget(self.status_label)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        layout.addWidget(self.progress)

        # Bottom buttons
        btn_layout = QHBoxLayout()
        layout.addLayout(btn_layout)

        self.apply_btn = QPushButton("Apply Result")
        self.apply_btn.setEnabled(False)
        self.apply_btn.clicked.connect(self._apply_result)
        btn_layout.addWidget(self.apply_btn)

        btn_layout.addStretch()

        self.close_btn = QPushButton("Close")
        self.close_btn.clicked.connect(self.reject)
        btn_layout.addWidget(self.close_btn)

    def _connect_signals(self):
        self.r_filter_combo.currentIndexChanged.connect(self._save_settings)
        self.g_filter_combo.currentIndexChanged.connect(self._save_settings)
        self.b_filter_combo.currentIndexChanged.connect(self._save_settings)
        self.sens_combo.currentIndexChanged.connect(self._save_settings)
        self.star_combo.currentIndexChanged.connect(self._save_settings)

    def _load_settings(self):
        s = QSettings()

        def apply_combo(cb, key):
            val = s.value(key, "")
            if val:
                idx = cb.findText(val)
                if idx != -1:
                    cb.setCurrentIndex(idx)

        apply_combo(self.star_combo, "SPCC/WhiteReference")
        apply_combo(self.r_filter_combo, "SPCC/RFilter")
        apply_combo(self.g_filter_combo, "SPCC/GFilter")
        apply_combo(self.b_filter_combo, "SPCC/BFilter")
        apply_combo(self.sens_combo, "SPCC/Sensor")

    def _save_settings(self, *args):
        s = QSettings()
        s.setValue("SPCC/WhiteReference", self.star_combo.currentText())
        s.setValue("SPCC/RFilter", self.r_filter_combo.currentText())
        s.setValue("SPCC/GFilter", self.g_filter_combo.currentText())
        s.setValue("SPCC/BFilter", self.b_filter_combo.currentText())
        s.setValue("SPCC/Sensor", self.sens_combo.currentText())

    def _load_from_ctx(self):
        """Load image from script context."""
        try:
            img = self.ctx.get_image()
            if img is not None:
                self.image = img.copy()
                h, w = img.shape[:2]
                self.status_label.setText(f"Loaded: {w}x{h} - Click 'Fetch Gaia Stars'")
                self.fetch_stars_btn.setEnabled(True)
            else:
                self.status_label.setText("No image in context")
        except Exception as e:
            self.status_label.setText(f"Error loading image: {e}")

    def _get_wcs_from_context(self):
        """Get WCS from context document metadata."""
        wcs_obj = None
        header = None

        # Get active document
        doc = None
        if hasattr(self.ctx, 'active_document'):
            doc = self.ctx.active_document()

        if doc and hasattr(doc, 'metadata'):
            meta = doc.metadata
            if meta:
                if 'wcs' in meta:
                    wcs_obj = meta['wcs']
                if 'wcs_header' in meta:
                    header = meta['wcs_header']

        return wcs_obj, header

    def _fetch_stars(self):
        """Fetch Gaia stars for the field using WCS."""
        if self.image is None:
            QMessageBox.warning(self, "No Image", "Please load an image first.")
            return

        # Get lazy-loaded modules
        astropy = _get_astropy()
        if not astropy:
            QMessageBox.critical(self, "Error", "Astropy not available")
            return
        WCS = astropy['WCS']
        SkyCoord = astropy['SkyCoord']
        u = astropy['u']

        Vizier = _get_vizier()
        if not Vizier:
            QMessageBox.critical(self, "Error", "Vizier/astroquery not available")
            return

        # Get WCS from context
        wcs_obj, header = self._get_wcs_from_context()

        if wcs_obj is None and header is None:
            QMessageBox.warning(self, "No Plate Solution",
                "No WCS found. Please plate-solve the image first.")
            return

        self.status_label.setText("Initializing WCS...")
        QApplication.processEvents()

        # Use WCS object or build from header
        if wcs_obj is not None:
            self.wcs = wcs_obj
        else:
            try:
                self.wcs = WCS(header, naxis=2)
            except Exception as e:
                QMessageBox.critical(self, "WCS Error", f"Could not build WCS:\n{e}")
                return

        # Ensure we have a 2D celestial WCS (handle 3D cubes, etc.)
        if self.wcs.naxis != 2:
            orig_naxis = self.wcs.naxis
            try:
                # Extract just the celestial (RA/Dec) part
                self.wcs = self.wcs.celestial
                print(f"[SPCC] Extracted 2D celestial WCS from {orig_naxis}D WCS")
            except Exception as e:
                QMessageBox.critical(self, "WCS Error",
                    f"WCS has {orig_naxis} dimensions and celestial extraction failed:\n{e}")
                return

        self.header = header

        # Calculate field center and radius
        H, W = self.image.shape[:2]
        try:
            center_coord = self.wcs.pixel_to_world(W/2, H/2)
            corners = [self.wcs.pixel_to_world(x, y) for x, y in [(0,0), (W,0), (W,H), (0,H)]]
            radius_deg = max(center_coord.separation(c).deg for c in corners) * 1.1
        except Exception as e:
            QMessageBox.critical(self, "WCS Error", f"WCS conversion failed:\n{e}")
            return

        self.field_center = center_coord
        self.field_radius_deg = radius_deg

        self.status_label.setText(f"Querying Gaia DR3 via VizieR (radius={radius_deg:.2f}°)...")
        QApplication.processEvents()

        # Query Gaia via VizieR
        try:
            v = Vizier(
                columns=['Source', 'RA_ICRS', 'DE_ICRS', 'Gmag', 'BP-RP', '+_r'],
                row_limit=10000,
                column_filters={"Gmag": "<16"}
            )
            result = v.query_region(center_coord, radius=radius_deg * u.deg, catalog="I/355/gaiadr3")

            if result is None or len(result) == 0:
                QMessageBox.warning(self, "No Stars", "No Gaia stars found in this region.")
                return

            table = result[0]
        except Exception as e:
            QMessageBox.critical(self, "Query Error", f"Failed to query Gaia:\n{e}")
            return

        # Convert to pixel coordinates
        self.star_list = []
        for row in table:
            try:
                ra = float(row['RA_ICRS'])
                dec = float(row['DE_ICRS'])
                gmag = float(row['Gmag']) if not np.ma.is_masked(row['Gmag']) else None
                bp_rp = float(row['BP-RP']) if not np.ma.is_masked(row['BP-RP']) else None
                source_id = int(row['Source']) if not np.ma.is_masked(row['Source']) else None

                if bp_rp is None or source_id is None:
                    continue

                coord = SkyCoord(ra=ra*u.deg, dec=dec*u.deg)
                px, py = self.wcs.world_to_pixel(coord)
                px, py = float(px), float(py)

                if 0 <= px < W and 0 <= py < H:
                    self.star_list.append({
                        'source_id': source_id,
                        'ra': ra,
                        'dec': dec,
                        'x': px,
                        'y': py,
                        'gmag': gmag,
                        'bp_rp': bp_rp,
                    })
            except:
                continue

        n_stars = len(self.star_list)
        if n_stars == 0:
            QMessageBox.warning(self, "No Stars", "No Gaia stars found in field of view.")
            return

        self.status_label.setText(f"Found {n_stars} Gaia stars - Ready to calibrate")
        self.run_btn.setEnabled(True)

        # Show BP-RP distribution histogram
        if _is_matplotlib_available() and hasattr(self, 'figure'):
            self.figure.clf()
            bp_rp_values = [s['bp_rp'] for s in self.star_list if s.get('bp_rp') is not None]
            if bp_rp_values:
                ax = self.figure.add_subplot(111)
                ax.hist(bp_rp_values, bins=30, edgecolor='black', alpha=0.7, color='steelblue')
                ax.set_xlabel("BP-RP Color")
                ax.set_ylabel("Count")
                ax.set_title(f"Gaia DR3 Color Distribution ({len(bp_rp_values)} stars in field)")
                ax.grid(axis='y', linestyle='--', alpha=0.3)
                self.figure.tight_layout()
                self.canvas.setVisible(True)
                self.canvas.draw()
            else:
                self.canvas.setVisible(False)

    def _load_curve(self, extname):
        """Load a curve from SASP data files."""
        astropy = _get_astropy()
        if not astropy:
            raise RuntimeError("Astropy not available")
        fits = astropy['fits']

        for path in [self.user_custom_path, self.sasp_data_path]:
            if not path or not os.path.exists(path):
                continue
            try:
                with fits.open(path, memmap=False) as hdul:
                    if extname in hdul:
                        d = hdul[extname].data
                        wl = _ensure_angstrom(d["WAVELENGTH"].astype(float))
                        # Try THROUGHPUT first, then TRANSMISSION
                        if "THROUGHPUT" in d.names:
                            tp = d["THROUGHPUT"].astype(float)
                        elif "TRANSMISSION" in d.names:
                            tp = d["TRANSMISSION"].astype(float)
                        else:
                            tp = d[d.names[1]].astype(float)
                        return wl, tp
            except Exception:
                continue
        raise KeyError(f"Curve '{extname}' not found")

    def _load_sed(self, extname):
        """Load an SED from SASP data files."""
        astropy = _get_astropy()
        if not astropy:
            raise RuntimeError("Astropy not available")
        fits = astropy['fits']

        for path in [self.user_custom_path, self.sasp_data_path]:
            if not path or not os.path.exists(path):
                continue
            try:
                with fits.open(path, memmap=False) as hdul:
                    if extname in hdul:
                        d = hdul[extname].data
                        wl = _ensure_angstrom(d["WAVELENGTH"].astype(float))
                        fl = d["FLUX"].astype(float)
                        return wl, fl
            except Exception:
                continue
        raise KeyError(f"SED '{extname}' not found")

    def _run_calibration(self):
        """Run SPCC calibration (like sfcc.py - no threading)."""
        if self.image is None or not self.star_list:
            QMessageBox.warning(self, "Error", "Please fetch stars first.")
            return

        # Get settings
        ref_sed_name = self.star_combo.currentData()
        ref_sed_text = self.star_combo.currentText()
        print(f"[SPCC] Combo selection - text: '{ref_sed_text}', data: '{ref_sed_name}'")

        # Fallback: if currentData() returned None, use the text (handle Vega special case)
        if ref_sed_name is None:
            ref_sed_name = "A0V" if "Vega" in ref_sed_text else ref_sed_text
            print(f"[SPCC] Using fallback SED name: '{ref_sed_name}'")

        r_filt = self.r_filter_combo.currentText()
        g_filt = self.g_filter_combo.currentText()
        b_filt = self.b_filter_combo.currentText()
        sens_name = self.sens_combo.currentText()
        lp_filt = self.lp_filter_combo.currentText()
        lp_filt2 = self.lp_filter_combo2.currentText()

        if not ref_sed_name:
            QMessageBox.warning(self, "Error", "Select a white reference.")
            return
        if sens_name == "(None)":
            QMessageBox.warning(self, "Error", "Select a sensor QE curve.")
            return

        # Get star limit
        limit_text = self.star_limit_combo.currentText()
        star_limit = 99999 if limit_text == "All" else int(limit_text)

        use_local_db = self.use_local_db_chk.isChecked()
        save_to_db = self.save_to_local_db_chk.isChecked()

        self.progress.setVisible(True)
        self.progress.setValue(0)
        self.run_btn.setEnabled(False)

        try:
            self._do_calibration(ref_sed_name, r_filt, g_filt, b_filt, sens_name,
                                lp_filt, lp_filt2, star_limit, use_local_db, save_to_db)
        except Exception as e:
            import traceback
            QMessageBox.critical(self, "Error", f"Calibration failed:\n{e}\n{traceback.format_exc()}")
        finally:
            self.progress.setVisible(False)
            self.run_btn.setEnabled(True)

    def _do_calibration(self, ref_sed_name, r_filt, g_filt, b_filt, sens_name,
                        lp_filt, lp_filt2, star_limit, use_local_db, save_to_db):
        """Core calibration logic (runs in main thread like sfcc.py)."""

        self.status_label.setText("Preparing image...")
        QApplication.processEvents()

        # Convert to float
        img = self.image.astype(np.float32)
        if img.max() > 1.5:
            img = img / 65535.0 if img.max() > 255 else img / 255.0

        H, W = img.shape[:2]

        # Pedestal removal
        for c in range(3):
            img[..., c] -= img[..., c].min()
        img = np.clip(img, 0, 1)

        # Build filter response curves
        self.status_label.setText("Loading filter curves...")
        self.progress.setValue(5)
        QApplication.processEvents()

        wl_min, wl_max = 3000, 11000
        wl_grid = np.arange(wl_min, wl_max + 1)

        def interp(wl_o, tp_o):
            return np.interp(wl_grid, wl_o, tp_o, left=0.0, right=0.0)

        T_R = interp(*self._load_curve(r_filt)) if r_filt != "(None)" else np.ones_like(wl_grid)
        T_G = interp(*self._load_curve(g_filt)) if g_filt != "(None)" else np.ones_like(wl_grid)
        T_B = interp(*self._load_curve(b_filt)) if b_filt != "(None)" else np.ones_like(wl_grid)
        QE = interp(*self._load_curve(sens_name)) if sens_name != "(None)" else np.ones_like(wl_grid)
        LP1 = interp(*self._load_curve(lp_filt)) if lp_filt != "(None)" else np.ones_like(wl_grid)
        LP2 = interp(*self._load_curve(lp_filt2)) if lp_filt2 != "(None)" else np.ones_like(wl_grid)
        LP = LP1 * LP2

        T_sys_R = T_R * QE * LP
        T_sys_G = T_G * QE * LP
        T_sys_B = T_B * QE * LP

        # Reference SED (white point definition)
        print(f"[SPCC] White reference: {ref_sed_name}")
        self.status_label.setText(f"Loading white reference: {ref_sed_name}...")
        QApplication.processEvents()

        wl_ref, fl_ref = self._load_sed(ref_sed_name)

        # DEBUG: Show SED loading details
        print(f"[SPCC DEBUG] SED '{ref_sed_name}' loaded:")
        print(f"[SPCC DEBUG]   Wavelength range: {wl_ref.min():.1f} - {wl_ref.max():.1f} Å ({len(wl_ref)} points)")
        print(f"[SPCC DEBUG]   Flux range: {fl_ref.min():.6f} - {fl_ref.max():.6f}")
        print(f"[SPCC DEBUG]   Flux sum: {fl_ref.sum():.6f}, mean: {fl_ref.mean():.6f}")
        print(f"[SPCC DEBUG] wl_grid range: {wl_grid.min():.1f} - {wl_grid.max():.1f} Å ({len(wl_grid)} points)")

        fr_i = np.interp(wl_grid, wl_ref, fl_ref, left=0.0, right=0.0)

        # DEBUG: Show interpolation results
        print(f"[SPCC DEBUG] Interpolated flux (fr_i):")
        print(f"[SPCC DEBUG]   Range: {fr_i.min():.6f} - {fr_i.max():.6f}")
        print(f"[SPCC DEBUG]   Sum: {fr_i.sum():.6f}, mean: {fr_i.mean():.6f}")
        print(f"[SPCC DEBUG]   Non-zero points: {np.sum(fr_i > 0)} / {len(fr_i)}")

        # DEBUG: Show system throughput
        print(f"[SPCC DEBUG] System throughput:")
        print(f"[SPCC DEBUG]   T_sys_R: sum={T_sys_R.sum():.4f}, max={T_sys_R.max():.4f}")
        print(f"[SPCC DEBUG]   T_sys_G: sum={T_sys_G.sum():.4f}, max={T_sys_G.max():.4f}")
        print(f"[SPCC DEBUG]   T_sys_B: sum={T_sys_B.sum():.4f}, max={T_sys_B.max():.4f}")

        S_ref_R = np.trapezoid(fr_i * T_sys_R, x=wl_grid)
        S_ref_G = np.trapezoid(fr_i * T_sys_G, x=wl_grid)
        S_ref_B = np.trapezoid(fr_i * T_sys_B, x=wl_grid)
        print(f"[SPCC] Reference integrals: R={S_ref_R:.4f}, G={S_ref_G:.4f}, B={S_ref_B:.4f}")

        # SEP star detection
        self.status_label.setText("Detecting stars with SEP...")
        self.progress.setValue(10)
        QApplication.processEvents()

        sep = _get_sep()
        if not sep:
            raise RuntimeError("SEP not available")

        gray = np.mean(img, axis=2).astype(np.float32)
        bkg = sep.Background(gray)
        data_sub = gray - bkg.back()
        err = float(bkg.globalrms)

        sep_sigma = float(self.sep_thr_spin.value())
        sources = sep.extract(data_sub, sep_sigma, err=err)

        if sources.size == 0:
            raise RuntimeError("SEP found no sources")

        print(f"[SPCC] SEP detected {sources.size} sources (raw)")

        # Flux radius filtering (like sfcc.py) - reject hot pixels and extended objects
        r_fluxrad, _ = sep.flux_radius(
            gray, sources["x"], sources["y"],
            2.0 * sources["a"], 0.5,
            normflux=sources["flux"], subpix=5
        )
        mask = (r_fluxrad > 0.2) & (r_fluxrad <= 10)
        sources = sources[mask]

        if sources.size == 0:
            raise RuntimeError("All SEP detections rejected by radius filter")

        print(f"[SPCC] SEP after flux radius filter: {sources.size} sources")

        # Match catalog stars to SEP detections (unique 1-to-1)
        self.status_label.setText("Matching catalog to detections...")
        self.progress.setValue(15)
        QApplication.processEvents()

        match_radius = 5.0
        sep_to_catalog = {}

        for i, star in enumerate(self.star_list):
            dx = sources["x"] - star["x"]
            dy = sources["y"] - star["y"]
            dist_sq = dx * dx + dy * dy
            j = int(np.argmin(dist_sq))
            d2 = float(dist_sq[j])

            if d2 < (match_radius ** 2):
                if j not in sep_to_catalog or d2 < sep_to_catalog[j][1]:
                    sep_to_catalog[j] = (i, d2, star)

        raw_matches = []
        for j, (cat_idx, dist_sq, star) in sep_to_catalog.items():
            xi = int(round(float(sources["x"][j])))
            yi = int(round(float(sources["y"][j])))
            if 0 <= xi < W and 0 <= yi < H:
                raw_matches.append({
                    "sim_index": cat_idx,
                    "sep_index": j,
                    "x_pix": xi,
                    "y_pix": yi,
                    "match_dist": np.sqrt(dist_sq)
                })

        # Matching summary (like sfcc.py)
        total_potential = sum(1 for i, star in enumerate(self.star_list)
                             if np.min((sources["x"] - star["x"])**2 + (sources["y"] - star["y"])**2) < match_radius**2)
        duplicates_prevented = total_potential - len(raw_matches)

        print(f"\n[SPCC] ===== STAR MATCHING SUMMARY =====")
        print(f"[SPCC] Catalog stars in field: {len(self.star_list)}")
        print(f"[SPCC] SEP detections: {sources.size}")
        print(f"[SPCC] Match radius: {match_radius:.1f} pixels")
        print(f"[SPCC] Unique 1-to-1 matches: {len(raw_matches)}")
        if duplicates_prevented > 0:
            print(f"[SPCC] Duplicate matches prevented: {duplicates_prevented}")
        print(f"[SPCC] =====================================\n")

        if not raw_matches:
            raise RuntimeError("No catalog stars matched to SEP detections")

        # Get matched stars with source_id, sort by brightness, apply limit
        matched_stars_info = []
        for m in raw_matches:
            star = self.star_list[m["sim_index"]]
            if star.get('source_id'):
                matched_stars_info.append({
                    'source_id': int(star['source_id']),
                    'gmag': star.get('gmag', 99),
                    'match_idx': m["sim_index"],
                    'ra': star.get('ra', 0),
                    'dec': star.get('dec', 0),
                    'bp_rp': star.get('bp_rp', 0),
                })

        matched_stars_info.sort(key=lambda x: x['gmag'])
        limited_stars = matched_stars_info[:star_limit]
        matched_source_ids = [s['source_id'] for s in limited_stars]

        print(f"[SPCC] Using {len(matched_source_ids)} brightest matched stars (limit={star_limit})")

        # Get XP spectra - check local DB first, download missing
        self.status_label.setText("Fetching XP spectra...")
        self.progress.setValue(25)
        QApplication.processEvents()

        xp_integrals = {}
        local_source_ids = set()
        db_path = get_local_gaia_db_path() if use_local_db else None

        # Get lazy-loaded gaia_downloader components
        gaia_dl = _get_gaia_downloader()
        local_db_available = gaia_dl and gaia_dl.get('available', False)
        GaiaSpectraDB = gaia_dl.get('GaiaSpectraDB') if gaia_dl else None
        GaiaSource = gaia_dl.get('GaiaSource') if gaia_dl else None
        CalibratedSpectrum = gaia_dl.get('CalibratedSpectrum') if gaia_dl else None

        # Check local database first
        if use_local_db and local_db_available and db_path and os.path.exists(db_path):
            self.status_label.setText("Checking local database...")
            QApplication.processEvents()

            try:
                db = GaiaSpectraDB(db_path)
                wavelengths = db.wavelengths
                xp_wavelength_A = wavelengths * 10.0  # nm to Angstrom

                for sid in matched_source_ids:
                    spectrum = db.get_spectrum(sid)
                    if spectrum is not None:
                        local_source_ids.add(sid)
                        flux = spectrum.flux
                        flux_interp = np.interp(wl_grid, xp_wavelength_A, flux, left=0.0, right=0.0)
                        S_R = np.trapezoid(flux_interp * T_sys_R, x=wl_grid)
                        S_G = np.trapezoid(flux_interp * T_sys_G, x=wl_grid)
                        S_B = np.trapezoid(flux_interp * T_sys_B, x=wl_grid)
                        if S_G > 0:
                            xp_integrals[sid] = (S_R, S_G, S_B)

                db.close()
                print(f"[SPCC] Found {len(local_source_ids)}/{len(matched_source_ids)} spectra in local DB")
            except Exception as e:
                print(f"[SPCC] Local DB error: {e}")

        # Download missing spectra
        missing_source_ids = [sid for sid in matched_source_ids if sid not in local_source_ids]
        gaiaxpy_calibrate = _get_gaiaxpy()

        if not missing_source_ids:
            print(f"[SPCC] All {len(matched_source_ids)} spectra found in local DB - no download needed")
        elif missing_source_ids and not gaiaxpy_calibrate:
            print(f"[SPCC] {len(missing_source_ids)} spectra not in local DB and GaiaXPy not available - skipping download")
        elif missing_source_ids and gaiaxpy_calibrate:
            # Download in batches of 50 to show progress
            batch_size = 50
            n_batches = (len(missing_source_ids) + batch_size - 1) // batch_size
            xp_sampling_nm = np.arange(336, 1021, 2)

            print(f"[SPCC] Downloading {len(missing_source_ids)} spectra from Gaia archive in {n_batches} batches...")
            self.status_label.setText(f"Downloading {len(missing_source_ids)} spectra from Gaia archive...")
            self.progress.setValue(35)
            QApplication.processEvents()

            all_downloaded = []
            sampling = None

            for batch_idx in range(0, len(missing_source_ids), batch_size):
                batch = missing_source_ids[batch_idx:batch_idx + batch_size]
                batch_num = batch_idx // batch_size + 1

                print(f"[SPCC] Batch {batch_num}/{n_batches}: Downloading {len(batch)} spectra...")
                self.status_label.setText(f"Downloading batch {batch_num}/{n_batches} ({len(batch)} spectra)...")
                # Update progress bar between 35-55% during download
                progress_pct = 35 + int(20 * batch_num / n_batches)
                self.progress.setValue(progress_pct)
                QApplication.processEvents()

                try:
                    calibrated_df, sampling = gaiaxpy_calibrate(batch, sampling=xp_sampling_nm, save_file=False)
                    if calibrated_df is not None and len(calibrated_df) > 0:
                        all_downloaded.append(calibrated_df)
                        print(f"[SPCC] Batch {batch_num}: Got {len(calibrated_df)} spectra")
                except Exception as batch_e:
                    print(f"[SPCC] Batch {batch_num} failed: {batch_e}")
                    continue

            # Combine all batches and process
            if all_downloaded:
                import pandas as pd
                calibrated_df = pd.concat(all_downloaded, ignore_index=True)
                print(f"[SPCC] Downloaded {len(calibrated_df)} spectra total")

                if sampling is not None:
                    xp_wavelength_A = sampling * 10.0

                    # Process downloaded spectra
                    for _, row in calibrated_df.iterrows():
                        sid = int(row['source_id'])
                        flux = np.array(row['flux'])
                        flux_interp = np.interp(wl_grid, xp_wavelength_A, flux, left=0.0, right=0.0)
                        S_R = np.trapezoid(flux_interp * T_sys_R, x=wl_grid)
                        S_G = np.trapezoid(flux_interp * T_sys_G, x=wl_grid)
                        S_B = np.trapezoid(flux_interp * T_sys_B, x=wl_grid)
                        if S_G > 0:
                            xp_integrals[sid] = (S_R, S_G, S_B)

                    # Save to local database if enabled
                    if save_to_db and local_db_available and GaiaSpectraDB:
                        self.status_label.setText("Saving to local database...")
                        QApplication.processEvents()

                        if db_path is None:
                            # Only location: scripts/spcc/ subdirectory
                            script_dir = os.path.dirname(os.path.abspath(__file__))
                            spcc_subdir = os.path.join(script_dir, "spcc")
                            if os.path.exists(spcc_subdir):
                                db_path = os.path.join(spcc_subdir, "gaia_spectra.db")
                            else:
                                print(f"[SPCC] Cannot save to DB: spcc subdirectory not found at {spcc_subdir}")
                                db_path = None

                        if db_path is None:
                            print(f"[SPCC] Skipping save - no valid database path")
                        else:
                            try:
                                db = GaiaSpectraDB(db_path)
                                n_saved = 0
                                for _, row in calibrated_df.iterrows():
                                    sid = int(row['source_id'])
                                    flux = np.array(row['flux'])
                                    star_info = next((s for s in limited_stars if s['source_id'] == sid), None)
                                    if star_info:
                                        source = GaiaSource(
                                            source_id=sid,
                                            ra=star_info.get('ra', 0),
                                            dec=star_info.get('dec', 0),
                                            phot_g_mean_mag=star_info.get('gmag', 0),
                                            bp_rp=star_info.get('bp_rp', 0),
                                            parallax=None, pmra=None, pmdec=None
                                        )
                                        db.add_source(source)
                                        spectrum = CalibratedSpectrum(
                                            source_id=sid,
                                            wavelengths=sampling,
                                            flux=flux,
                                            flux_error=None
                                        )
                                        db.add_spectrum(spectrum)
                                        n_saved += 1
                                db.close()
                                print(f"[SPCC] Saved {n_saved} spectra to local DB")
                            except Exception as e:
                                print(f"[SPCC] Error saving to DB: {e}")
            else:
                print(f"[SPCC] No spectra were successfully downloaded")

        if not xp_integrals:
            raise RuntimeError("No XP spectra available for matched stars")

        print(f"[SPCC] Have XP integrals for {len(xp_integrals)} stars")

        # Photometry (matching sfcc.py's robust approach)
        self.status_label.setText("Measuring star fluxes...")
        self.progress.setValue(60)
        QApplication.processEvents()

        aperture = self.aperture_spin.value()
        bg_inner = self.bg_inner_spin.value()
        bg_outer = self.bg_outer_spin.value()
        sat_thresh = self.sat_spin.value()
        snr_thresh = self.snr_spin.value()

        # Color ratio bounds for rejecting mismatches
        color_ratio_min = 0.65
        color_ratio_max = 1.55

        # Sigma-clipped background estimation (uses user's sigma clip setting)
        bg_sigma_clip = self.sigma_spin.value()
        def sigma_clip_median(arr):
            med = np.median(arr)
            std = np.std(arr)
            mask = np.abs(arr - med) < bg_sigma_clip * std
            return float(np.median(arr[mask])) if np.any(mask) else float(med)

        enriched = []

        # Rejection counters
        n_no_xp = 0
        n_negative_flux = 0
        n_saturated = 0
        n_not_centered = 0
        n_low_snr = 0
        n_color_rejected = 0

        for m in raw_matches:
            star = self.star_list[m["sim_index"]]
            sid = star.get('source_id')
            if sid not in xp_integrals:
                n_no_xp += 1
                continue

            cx, cy = star['x'], star['y']
            xi, yi = int(round(cx)), int(round(cy))

            margin = bg_outer + 1
            if xi < margin or xi >= W - margin or yi < margin or yi >= H - margin:
                continue

            cutout = img[yi - margin:yi + margin + 1, xi - margin:xi + margin + 1]

            # Local coordinates
            cy_local = margin
            cx_local = margin
            yy, xx = np.ogrid[:cutout.shape[0], :cutout.shape[1]]
            dist_sq = (yy - cy_local)**2 + (xx - cx_local)**2

            star_mask = dist_sq <= aperture**2
            bg_mask = (dist_sq >= bg_inner**2) & (dist_sq <= bg_outer**2)

            if not np.any(star_mask) or not np.any(bg_mask):
                continue

            # Sigma-clipped background per channel
            bg_pixels_R = cutout[:, :, 0][bg_mask]
            bg_pixels_G = cutout[:, :, 1][bg_mask]
            bg_pixels_B = cutout[:, :, 2][bg_mask]

            bg_R = sigma_clip_median(bg_pixels_R)
            bg_G = sigma_clip_median(bg_pixels_G)
            bg_B = sigma_clip_median(bg_pixels_B)

            # Gaussian-weighted flux (PSF-like photometry)
            dist = np.sqrt(dist_sq)
            sigma_psf = aperture / 2.5
            weights = np.exp(-0.5 * (dist / sigma_psf)**2)
            weights[~star_mask] = 0
            weights = weights / np.sum(weights)

            # Weighted flux measurement
            Rm = float(np.sum((cutout[:, :, 0] - bg_R) * weights))
            Gm = float(np.sum((cutout[:, :, 1] - bg_G) * weights))
            Bm = float(np.sum((cutout[:, :, 2] - bg_B) * weights))

            # Scale to approximate total flux
            n_pix = float(np.sum(star_mask))
            Rm *= n_pix
            Gm *= n_pix
            Bm *= n_pix

            if Rm <= 0 or Gm <= 0 or Bm <= 0:
                n_negative_flux += 1
                continue

            # Saturation check
            peak_val = float(np.max(cutout[star_mask]))
            if peak_val > sat_thresh:
                n_saturated += 1
                continue

            # Verify star is centered (peak within 70% of aperture radius)
            gray_cutout = cutout[:, :, 1]
            masked_gray = np.where(star_mask, gray_cutout, 0)
            peak_y, peak_x = np.unravel_index(np.argmax(masked_gray), masked_gray.shape)
            peak_offset = np.sqrt((peak_x - cx_local)**2 + (peak_y - cy_local)**2)
            if peak_offset > aperture * 0.7:
                n_not_centered += 1
                continue

            # Per-channel SNR check
            bg_std_R = float(np.std(bg_pixels_R))
            bg_std_G = float(np.std(bg_pixels_G))
            bg_std_B = float(np.std(bg_pixels_B))
            snr_R = Rm / (bg_std_R * np.sqrt(n_pix)) if bg_std_R > 0 else 0
            snr_G = Gm / (bg_std_G * np.sqrt(n_pix)) if bg_std_G > 0 else 0
            snr_B = Bm / (bg_std_B * np.sqrt(n_pix)) if bg_std_B > 0 else 0
            min_snr = min(snr_R, snr_G, snr_B)

            if min_snr < snr_thresh:
                n_low_snr += 1
                continue

            S_sr, S_sg, S_sb = xp_integrals[sid]
            exp_RG = (S_sr / S_sg) * (S_ref_G / S_ref_R)
            exp_BG = (S_sb / S_sg) * (S_ref_G / S_ref_B)
            meas_RG = Rm / Gm
            meas_BG = Bm / Gm

            # Color consistency check - reject obvious mismatches
            rg_ratio = meas_RG / exp_RG if exp_RG > 0 else 999
            bg_ratio = meas_BG / exp_BG if exp_BG > 0 else 999

            if rg_ratio < color_ratio_min or rg_ratio > color_ratio_max:
                n_color_rejected += 1
                continue
            if bg_ratio < color_ratio_min or bg_ratio > color_ratio_max:
                n_color_rejected += 1
                continue

            # Normalize measured RGB by G (so G=1)
            meas_R_n = Rm / Gm
            meas_G_n = 1.0
            meas_B_n = Bm / Gm

            # Expected RGB normalized by reference white point
            # These are what the star SHOULD measure as, normalized so G2V -> (1,1,1)
            pred_R_n = (S_sr / S_sg) * (S_ref_G / S_ref_R)
            pred_G_n = 1.0
            pred_B_n = (S_sb / S_sg) * (S_ref_G / S_ref_B)

            enriched.append({
                'meas_RG': meas_RG, 'meas_BG': meas_BG,
                'exp_RG': exp_RG, 'exp_BG': exp_BG,
                'meas_R_n': meas_R_n, 'meas_G_n': meas_G_n, 'meas_B_n': meas_B_n,
                'pred_R_n': pred_R_n, 'pred_G_n': pred_G_n, 'pred_B_n': pred_B_n,
                'snr': min_snr,
            })

        # Rejection summary
        print(f"\n[SPCC] ===== REJECTION SUMMARY =====")
        print(f"[SPCC] Total matched stars: {len(raw_matches)}")
        print(f"[SPCC] Rejected - no XP spectrum: {n_no_xp}")
        print(f"[SPCC] Rejected - negative flux: {n_negative_flux}")
        print(f"[SPCC] Rejected - not centered: {n_not_centered}")
        print(f"[SPCC] Rejected - low SNR: {n_low_snr}")
        print(f"[SPCC] Rejected - saturated: {n_saturated}")
        print(f"[SPCC] Rejected - color mismatch: {n_color_rejected}")
        print(f"[SPCC] Stars passing all filters: {len(enriched)}")
        print(f"[SPCC] ================================\n")

        if len(enriched) < 5:
            raise RuntimeError(f"Only {len(enriched)} stars passed filters (need at least 5)")

        # Fit color matrix (full 3x3 like sfcc.py)
        self.status_label.setText("Fitting 3x3 color matrix...")
        self.progress.setValue(80)
        QApplication.processEvents()

        # Extract data for matrix fit
        meas_RG = np.array([e['meas_RG'] for e in enriched])
        meas_BG = np.array([e['meas_BG'] for e in enriched])
        exp_RG = np.array([e['exp_RG'] for e in enriched])
        exp_BG = np.array([e['exp_BG'] for e in enriched])
        snr = np.array([e['snr'] for e in enriched])

        # For full 3x3 matrix: measured RGB and predicted RGB
        meas_R_n = np.array([e['meas_R_n'] for e in enriched])
        meas_G_n = np.array([e['meas_G_n'] for e in enriched])
        meas_B_n = np.array([e['meas_B_n'] for e in enriched])
        pred_R_n = np.array([e['pred_R_n'] for e in enriched])
        pred_G_n = np.array([e['pred_G_n'] for e in enriched])
        pred_B_n = np.array([e['pred_B_n'] for e in enriched])

        # Stack into matrices: M (measured), P (predicted)
        M = np.column_stack([meas_R_n, meas_G_n, meas_B_n])  # N x 3
        P = np.column_stack([pred_R_n, pred_G_n, pred_B_n])  # N x 3

        # SNR-based weights
        weights = np.clip(snr / snr.max(), 0.01, 1.0) ** 2
        sigma_clip_val = self.sigma_spin.value()

        def weighted_lstsq_3x3(M, P, weights, sigma_thresh=2.5, max_iter=5,
                               regularization=0.01, min_stars_for_full=15,
                               skip_cond_check=False, force_diagonal=False):
            """
            Solve weighted least squares: A @ m_i ≈ p_i
            Returns 3×3 matrix A, inlier mask, and whether diagonal-only was used.
            """
            N = M.shape[0]
            mask = np.ones(N, dtype=bool)
            A = np.eye(3)
            use_diagonal_only = force_diagonal or (N < min_stars_for_full)

            for iteration in range(max_iter):
                n_valid = np.sum(mask)
                if n_valid < 5:
                    use_diagonal_only = True
                    break

                W_sqrt = np.sqrt(weights[mask])

                if use_diagonal_only:
                    # Diagonal-only: solve each channel independently
                    A_new = np.eye(3)
                    for ch in range(3):
                        m_w = M[mask, ch] * W_sqrt
                        p_w = P[mask, ch] * W_sqrt
                        A_new[ch, ch] = np.sum(m_w * p_w) / (np.sum(m_w * m_w) + 1e-10)
                else:
                    # Full 3x3 matrix via ridge regression toward identity
                    # Minimizes |A @ M - P|² + λ|A - I|² (pushes A toward identity)
                    A_new = np.zeros((3, 3))
                    for ch in range(3):
                        M_w = M[mask] * W_sqrt[:, np.newaxis]
                        p_w = P[mask, ch] * W_sqrt
                        MtM = M_w.T @ M_w
                        Mtp = M_w.T @ p_w
                        reg_matrix = regularization * np.eye(3)
                        # Add λ * identity_row to RHS to regularize toward identity
                        identity_row = np.zeros(3)
                        identity_row[ch] = regularization
                        try:
                            A_new[ch, :] = np.linalg.solve(MtM + reg_matrix, Mtp + identity_row)
                        except np.linalg.LinAlgError:
                            use_diagonal_only = True
                            A_new = np.eye(3)
                            break

                A = A_new

                # Check condition number (unless forced to skip)
                if not use_diagonal_only and not skip_cond_check:
                    cond = np.linalg.cond(A)
                    if cond > 50:
                        print(f"[SPCC] High condition number ({cond:.1f}), switching to diagonal")
                        use_diagonal_only = True
                        continue

                # Compute residuals and reject outliers
                P_pred = M @ A.T
                residuals = np.linalg.norm(P - P_pred, axis=1)
                res_valid = residuals[mask]
                med_res = np.median(res_valid)
                std_res = np.std(res_valid)

                outlier_mask = residuals > (med_res + sigma_thresh * std_res)
                n_rejected = np.sum(mask & outlier_mask)

                if n_rejected == 0:
                    break

                mask = mask & ~outlier_mask
                print(f"[SPCC] Matrix fit iter {iteration+1}: rejected {n_rejected}, remaining {np.sum(mask)}")

            return A, mask, use_diagonal_only

        # Fit the 3×3 matrix
        use_full_matrix = self.use_full_matrix_chk.isChecked()
        min_stars_for_3x3 = self.min_stars_3x3_spin.value()
        force_3x3 = self.force_3x3_chk.isChecked()
        reg_mult = self.reg_spin.value()
        reg_value = 1.0 * reg_mult  # Base regularization × multiplier (higher base for stronger effect)

        if not use_full_matrix:
            print(f"[SPCC] User selected diagonal-only matrix mode")
        else:
            force_str = " (forced)" if force_3x3 else ""
            print(f"[SPCC] Attempting full 3×3 matrix (min stars: {min_stars_for_3x3}, reg: {reg_value:.4f}){force_str}")

        A_matrix, fit_mask, used_diagonal_only = weighted_lstsq_3x3(
            M, P, weights,
            sigma_thresh=sigma_clip_val,
            regularization=reg_value,
            min_stars_for_full=min_stars_for_3x3,
            skip_cond_check=force_3x3,
            force_diagonal=not use_full_matrix)

        n_used = int(np.sum(fit_mask))
        matrix_type = "diagonal-only" if used_diagonal_only else "full 3x3"
        print(f"[SPCC] Matrix fit complete ({matrix_type}): used {n_used}/{len(enriched)} stars")

        # Print the matrix
        print(f"[SPCC] Color correction matrix A (maps measured → predicted):")
        print(f"       [{A_matrix[0,0]:+.4f}  {A_matrix[0,1]:+.4f}  {A_matrix[0,2]:+.4f}]   [R]   [R']")
        print(f"       [{A_matrix[1,0]:+.4f}  {A_matrix[1,1]:+.4f}  {A_matrix[1,2]:+.4f}] × [G] = [G']")
        print(f"       [{A_matrix[2,0]:+.4f}  {A_matrix[2,1]:+.4f}  {A_matrix[2,2]:+.4f}]   [B]   [B']")

        # Compute fit quality
        P_pred = M @ A_matrix.T
        residuals = np.linalg.norm(P - P_pred, axis=1)
        rms_residual = float(np.sqrt(np.mean(residuals[fit_mask]**2)))
        print(f"[SPCC] RMS residual: {rms_residual:.4f}")

        # Extract diagonal elements for backward compatibility
        kr = A_matrix[0, 0]
        kb = A_matrix[2, 2]

        # For plotting, use the fit_mask for both R and B
        mask_R = fit_mask
        mask_B = fit_mask

        print(f"[SPCC] Diagonal elements: R={kr:.4f}, G={A_matrix[1,1]:.4f}, B={kb:.4f}")
        print(f"[SPCC] Stars used in fit: {fit_mask.sum()}")

        # Compute corrected ratios for "AFTER" plot using full matrix
        M_corrected = M @ A_matrix.T  # N x 3
        # Corrected ratios: R'/G' and B'/G'
        corr_RG = M_corrected[:, 0] / M_corrected[:, 1]
        corr_BG = M_corrected[:, 2] / M_corrected[:, 1]

        # Compute residual scatter (sigma) and offset for pre and post calibration
        # Pre-calibration: how far measured is from expected
        sigma_pre_R = np.std(meas_RG[mask_R] - exp_RG[mask_R])
        sigma_pre_B = np.std(meas_BG[mask_B] - exp_BG[mask_B])
        offset_pre_R = np.mean(meas_RG[mask_R] - exp_RG[mask_R])
        offset_pre_B = np.mean(meas_BG[mask_B] - exp_BG[mask_B])
        # Post-calibration: how far corrected is from expected
        sigma_post_R = np.std(corr_RG[mask_R] - exp_RG[mask_R])
        sigma_post_B = np.std(corr_BG[mask_B] - exp_BG[mask_B])
        offset_post_R = np.mean(corr_RG[mask_R] - exp_RG[mask_R])
        offset_post_B = np.mean(corr_BG[mask_B] - exp_BG[mask_B])

        print(f"[SPCC] R/G - Scatter: {sigma_pre_R:.4f} -> {sigma_post_R:.4f}, Offset: {offset_pre_R:+.4f} -> {offset_post_R:+.4f}")
        print(f"[SPCC] B/G - Scatter: {sigma_pre_B:.4f} -> {sigma_post_B:.4f}, Offset: {offset_pre_B:+.4f} -> {offset_post_B:+.4f}")

        # ---- Diagnostic plots (BEFORE and AFTER calibration) ----
        if _is_matplotlib_available() and hasattr(self, 'figure'):
            self.status_label.setText("Generating diagnostic plots...")
            QApplication.processEvents()

            self.figure.clf()
            # Make figure wider to accommodate legends
            self.figure.set_size_inches(14, 4.5)

            # Determine axis limits
            all_exp = np.concatenate([exp_RG, exp_BG])
            all_meas = np.concatenate([meas_RG, meas_BG])
            all_corr = np.concatenate([corr_RG, corr_BG])
            axis_min = float(min(all_exp.min(), all_meas.min(), all_corr.min()))
            axis_max = float(max(all_exp.max(), all_meas.max(), all_corr.max()))
            pad = 0.05 * (axis_max - axis_min) if axis_max > axis_min else 0.05
            axis_lim = (axis_min - pad, axis_max + pad)
            x_line = np.array([axis_min - pad, axis_max + pad])

            # Proper linear fits (y = mx + b) for both BEFORE and AFTER
            # BEFORE: fit measured vs expected
            if mask_R.sum() > 1:
                fit_pre_R = np.polyfit(exp_RG[mask_R], meas_RG[mask_R], 1)
                slope_pre_R, intercept_pre_R = fit_pre_R
            else:
                slope_pre_R, intercept_pre_R = 1.0, 0.0

            if mask_B.sum() > 1:
                fit_pre_B = np.polyfit(exp_BG[mask_B], meas_BG[mask_B], 1)
                slope_pre_B, intercept_pre_B = fit_pre_B
            else:
                slope_pre_B, intercept_pre_B = 1.0, 0.0

            # BEFORE: measured vs expected (left side: plot takes ~35%, legend ~15%)
            ax1 = self.figure.add_axes([0.06, 0.12, 0.28, 0.78])  # [left, bottom, width, height]

            ax1.scatter(exp_RG[mask_R], meas_RG[mask_R], c="firebrick", marker="o", alpha=0.6, s=20, label="R/G")
            ax1.scatter(exp_RG[~mask_R], meas_RG[~mask_R], c="firebrick", marker="o", alpha=0.15, s=15)
            ax1.scatter(exp_BG[mask_B], meas_BG[mask_B], c="royalblue", marker="s", alpha=0.6, s=20, label="B/G")
            ax1.scatter(exp_BG[~mask_B], meas_BG[~mask_B], c="royalblue", marker="s", alpha=0.15, s=15)

            # Pre-calibration fit lines (y = mx + b)
            ax1.plot(x_line, slope_pre_R * x_line + intercept_pre_R, c="darkred", lw=2,
                     label=f"R: k={slope_pre_R:.2f} b={intercept_pre_R:+.2f} s={sigma_pre_R:.3f}")
            ax1.plot(x_line, slope_pre_B * x_line + intercept_pre_B, c="darkblue", lw=2,
                     label=f"B: k={slope_pre_B:.2f} b={intercept_pre_B:+.2f} s={sigma_pre_B:.3f}")

            # Ideal line (y = x) for reference
            ax1.plot(x_line, x_line, color="0.5", ls="--", lw=1, alpha=0.5, label="y=x")

            # White reference point at (1.0, 1.0)
            ax1.scatter([1.0], [1.0], c="gold", marker="*", s=150, edgecolors="black",
                        linewidths=1, zorder=10, label="White ref")

            ax1.set_xlim(*axis_lim)
            ax1.set_ylim(*axis_lim)
            ax1.set_xlabel("Expected ratio")
            ax1.set_ylabel("Measured ratio")
            ax1.set_title(f"BEFORE (n={len(enriched)})")
            ax1.set_aspect("equal", adjustable="box")
            ax1.legend(frameon=True, fontsize=6, loc="upper left", bbox_to_anchor=(1.02, 1.0),
                       borderaxespad=0, framealpha=0.95)
            ax1.grid(True, alpha=0.3, linestyle="--")

            # AFTER: corrected vs expected (right side)
            ax2 = self.figure.add_axes([0.56, 0.12, 0.28, 0.78])

            ax2.scatter(exp_RG[mask_R], corr_RG[mask_R], c="firebrick", marker="o", alpha=0.7, s=20, label="R/G")
            ax2.scatter(exp_RG[~mask_R], corr_RG[~mask_R], c="firebrick", marker="o", alpha=0.2, s=15)
            ax2.scatter(exp_BG[mask_B], corr_BG[mask_B], c="royalblue", marker="s", alpha=0.7, s=20, label="B/G")
            ax2.scatter(exp_BG[~mask_B], corr_BG[~mask_B], c="royalblue", marker="s", alpha=0.2, s=15)

            # Ideal line (y = x)
            ax2.plot(x_line, x_line, color="0.5", ls="--", lw=1.5, label="y=x (ideal)")

            # Post-calibration fit lines (y = mx + b)
            if mask_R.sum() > 1:
                fit_post_R = np.polyfit(exp_RG[mask_R], corr_RG[mask_R], 1)
                slope_post_R, intercept_post_R = fit_post_R
            else:
                slope_post_R, intercept_post_R = 1.0, 0.0

            if mask_B.sum() > 1:
                fit_post_B = np.polyfit(exp_BG[mask_B], corr_BG[mask_B], 1)
                slope_post_B, intercept_post_B = fit_post_B
            else:
                slope_post_B, intercept_post_B = 1.0, 0.0

            ax2.plot(x_line, slope_post_R * x_line + intercept_post_R, c="darkred", lw=2, alpha=0.8,
                     label=f"R: k={slope_post_R:.2f} b={intercept_post_R:+.2f} s={sigma_post_R:.3f}")
            ax2.plot(x_line, slope_post_B * x_line + intercept_post_B, c="darkblue", lw=2, alpha=0.8,
                     label=f"B: k={slope_post_B:.2f} b={intercept_post_B:+.2f} s={sigma_post_B:.3f}")

            # White reference point at (1.0, 1.0)
            ax2.scatter([1.0], [1.0], c="gold", marker="*", s=150, edgecolors="black",
                        linewidths=1, zorder=10, label="White ref")

            ax2.set_xlim(*axis_lim)
            ax2.set_ylim(*axis_lim)
            ax2.set_xlabel("Expected ratio")
            ax2.set_ylabel("Corrected ratio")
            ax2.set_title("AFTER")
            ax2.set_aspect("equal", adjustable="box")
            ax2.legend(frameon=True, fontsize=6, loc="upper left", bbox_to_anchor=(1.02, 1.0),
                       borderaxespad=0, framealpha=0.95)
            ax2.grid(True, alpha=0.3, linestyle="--")

            self.canvas.setVisible(True)
            self.canvas.draw()

        # Apply calibration using full 3x3 matrix
        self.status_label.setText("Applying color matrix...")
        self.progress.setValue(90)
        QApplication.processEvents()

        # Build the final color matrix
        color_matrix = A_matrix.copy().astype(np.float32)

        pixels = img.reshape(-1, 3)
        corrected = pixels @ color_matrix.T
        calibrated = corrected.reshape(H, W, 3)

        # Background neutralization
        if self.bg_neutral_chk.isChecked():
            self.status_label.setText("Neutralizing background...")
            QApplication.processEvents()

            gray = np.mean(calibrated, axis=2)
            thresh = np.percentile(gray, 10)
            bg_mask = gray < thresh

            if bg_mask.sum() > 100:
                bg_r = np.median(calibrated[:, :, 0][bg_mask])
                bg_g = np.median(calibrated[:, :, 1][bg_mask])
                bg_b = np.median(calibrated[:, :, 2][bg_mask])

                if bg_g > 0:
                    calibrated[:, :, 0] = calibrated[:, :, 0] - bg_r + bg_g
                    calibrated[:, :, 2] = calibrated[:, :, 2] - bg_b + bg_g

        self.calibrated = np.clip(calibrated, 0, 1).astype(np.float32)
        self.progress.setValue(100)

        self.status_label.setText(
            f"Done! {matrix_type} matrix, RMS={rms_residual:.4f}, "
            f"{n_used} stars, ref={ref_sed_name}")
        self.apply_btn.setEnabled(True)

    def _apply_result(self):
        """Apply calibrated result back through context."""
        if not hasattr(self, 'calibrated') or self.calibrated is None:
            return

        try:
            self.ctx.set_image(self.calibrated)
            self.status_label.setText("Result applied to image")
            QMessageBox.information(self, "SPCC", "Calibration applied successfully!")
            self.accept()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to apply result: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# SASpro Script Entry Point
# ─────────────────────────────────────────────────────────────────────────────

def run(ctx):
    """SASpro script entry point for SPCC."""
    if not _is_astropy_available():
        QMessageBox.critical(None, "SPCC Error",
            "Astropy is required.\nInstall with: pip install astropy astroquery")
        return

    if not _is_sep_available():
        QMessageBox.critical(None, "SPCC Error",
            "SEP is required.\nInstall with: pip install sep")
        return

    dialog = SPCCDialog(ctx)
    dialog.exec()
