# SPCC (Spectrophotometric Color Calibration) - Development Log

## Overview

`spcc.py` implements **Spectrophotometric Color Calibration** for SASpro.using low-resolution stellar spectra from **Gaia DR3 XP** (BP/RP spectrophotometry) to compute precisely what colors stars *should* appear through your specific imaging system.

## Algorithm Workflow

### Stage 0: Build System Response Model
Combines user-selected curves to define effective channel responses:

```
S_R(λ) = QE(λ) × T_R(λ) × LP(λ)
S_G(λ) = QE(λ) × T_G(λ) × LP(λ)
S_B(λ) = QE(λ) × T_B(λ) × LP(λ)
```

Where:
- `QE(λ)` = Sensor quantum efficiency
- `T_R/G/B(λ)` = RGB filter transmission curves
- `LP(λ)` = Light pollution filter (if any)

### Stage 1: White Reference Definition
Loads the selected white reference SED (e.g., G2V for sun-like neutral) and computes reference integrals:

```
S_ref_R = ∫ W(λ) × S_R(λ) dλ
S_ref_G = ∫ W(λ) × S_G(λ) dλ
S_ref_B = ∫ W(λ) × S_B(λ) dλ
```

### Stage 2: Star Detection (SEP)
Uses SEP (Source Extractor for Python) to detect stars:
1. Background estimation and subtraction
2. Source extraction with configurable σ threshold
3. Flux radius filtering to reject hot pixels and extended objects

### Stage 3: Catalog Query & Cross-Match
1. Query Gaia DR3 via VizieR for stars in field (using WCS)
2. Cross-match detected sources to catalog within 5 pixel tolerance
3. Unique 1-to-1 matching (prevents duplicates)

### Stage 4: XP Spectra Retrieval
For each matched star with a Gaia source_id:
1. Check local SQLite database first (fast, offline)
2. Download missing spectra via GaiaXPy in batches of 50
3. Optionally save downloaded spectra to local DB for future use

### Stage 5: Synthetic Photometry
For each star with XP spectrum F(λ):

```
predicted_R = ∫ F(λ) × S_R(λ) dλ
predicted_G = ∫ F(λ) × S_G(λ) dλ
predicted_B = ∫ F(λ) × S_B(λ) dλ
```

Normalized by white reference so the reference SED maps to (1, 1, 1).

### Stage 6: Aperture Photometry
For each matched star, measure actual RGB fluxes:
1. Gaussian-weighted PSF photometry within aperture
2. Sigma-clipped background estimation from annulus
3. Per-channel SNR calculation
4. Rejection of saturated, low-SNR, off-center, and color-mismatched stars

### Stage 7: Full 3×3 Matrix Fitting
Solve weighted least squares: `A @ measured ≈ predicted`

```python
# For each output channel:
A[ch, :] = solve(M.T @ W @ M + λI, M.T @ W @ p[ch])
```

Features:
- Ridge regularization (λ=0.01) for numerical stability
- Iterative σ-clipping outlier rejection
- Falls back to diagonal-only if < 15 stars or condition number > 50
- SNR-weighted fitting (higher SNR stars have more influence)

### Stage 8: Apply Calibration
Transform every pixel: `RGB' = A × RGB`

Optional background neutralization adjusts R and B channels so the darkest 10% of pixels become neutral gray.

---

## Dependencies

### Required
```bash
pip install numpy astropy astroquery sep
```

### Optional (for XP spectra download)
```bash
pip install gaiaxpy pandas
```

### Data Files
- **SASP_data.fits** - Contains filter curves, sensor QE curves, and SED templates
- **gaia_spectra.db** - Local SQLite database of cached Gaia XP spectra (optional but recommended)

### Local Gaia Database Module
The script uses `gaia_downloader.py` for local spectrum caching.

The module provides:
- `GaiaSpectraDB` - SQLite database interface
- `CalibratedSpectrum` - Spectrum data container
- `GaiaSource` - Source metadata container

---

## File Structure

The expected file layout is:
```
C:\Users\{USERNAME}\AppData\Local\SASpro\scripts\
├── spcc.py                    # Main SPCC script
└── spcc\                      # Subdirectory for SPCC support files
    ├── gaia_downloader.py     # Local database module
    └── gaia_spectra.db        # Cached Gaia XP spectra database
```

**Important:** The `gaia_downloader.py` module and `gaia_spectra.db` database must be located in the `scripts/spcc/` subdirectory. There are no fallback locations - this is the only supported path.

---

## Setup

### 1. Install Dependencies
```bash
pip install numpy astropy astroquery sep gaiaxpy pandas
```

### 2. Ensure Data Files
Place `SASP_data.fits` in one of:
- `~/setiastrosuitepro/src/setiastro/data/`
- Same directory as script


### 3. Create the spcc Subdirectory
Create a `spcc` folder in your scripts directory and place:
- `gaia_downloader.py` - The local database module
- `gaia_spectra.db` - Will be created automatically when spectra are downloaded, or can be pre-populated

### Local Database Benefits

Enabling "Save to DB" allows the database to grow over time as you process different targets. Each calibration session adds new spectra for stars in that field, building a collection that covers your imaging history. This means:

- **Faster calibration** - Stars you've imaged before won't require re-downloading
- **Offline capability** - Once spectra are cached, no internet connection is needed
- **Cumulative coverage** - Your database expands to cover your typical imaging regions

A star limit of **500** is a good starting point. If calibration results are unsatisfactory or you want more precision, increase the star count - the script will automatically download and add any new stars to the database. Over time, your database will contain spectra for most stars in your commonly imaged regions.

**Note on download times:** Depending on your internet connection and Gaia archive server load, downloading spectra for ~500 stars can take 20-30 minutes. Consider taking a coffee break or running the first calibration overnight. Subsequent runs on the same field will be much faster since spectra are cached locally.

### Additional Performance Factors

You may notice subsequent runs are faster even beyond the database caching:

- **VizieR query caching** - The astroquery library may cache catalog queries briefly, making the "Fetch Gaia Stars" step faster on repeated runs of the same field
- **OS file caching** - Your operating system caches recently accessed files in RAM, so the SQLite database reads become even faster after the first access
- **Python module caching** - Lazy-loaded modules (astropy, sep, gaiaxpy, etc.) stay in memory between calibration runs within the same session, eliminating import overhead

These effects are most noticeable when running multiple calibrations in the same session without closing SASpro.

In the future, a community-contributed database could be created, allowing users to share their cached spectra collections. This would provide instant coverage for popular imaging targets without requiring individual downloads from the Gaia archive.

---

## User Interface

### Main Controls

| Control | Description |
|---------|-------------|
| **Fetch Gaia Stars** | Query Gaia DR3 for stars in the image field (requires plate-solved WCS) |
| **Run Color Calibration** | Execute the full SPCC pipeline |
| **Apply Result** | Apply calibrated image back to SASpro |

### Configuration Options

| Option | Description | Default |
|--------|-------------|---------|
| **Use Local DB** | Check local database before downloading | On (if available) |
| **Save to DB** | Cache downloaded spectra for future use | On |
| **Star Limit** | Max stars to use (brightest first) | 200 |
| **White Reference** | SED for neutral white definition | G2V |
| **R/G/B Filters** | Your imaging filter curves | (None) |
| **Sensor (QE)** | Your sensor's quantum efficiency curve | Required |
| **LP Filters** | Light pollution filter curves | (None) |
| **Background Neutralization** | Neutralize darkest pixels after calibration | On |
| **Star detect σ** | SEP detection threshold | 5 |

### Advanced Photometry Settings

**For most images, the default values work well - start with the defaults and only adjust if needed.**

These settings control how star fluxes are measured and are provided for exceptional cases (very crowded fields, unusual seeing conditions, etc.). Each setting has a tooltip in the UI - hover over the control for detailed explanations.

| Setting | Description | Default |
|---------|-------------|---------|
| **Aperture (px)** | Radius for star flux measurement | 8 |
| **BG inner** | Inner radius of background annulus | 12 |
| **BG outer** | Outer radius of background annulus | 18 |
| **SNR threshold** | Minimum signal-to-noise ratio | 5.0 |
| **Saturation** | Max pixel value (0-1) before rejection | 0.95 |
| **Sigma clip** | σ for outlier rejection | 2.5 |
| **Use full 3×3 matrix** | Enable full matrix vs diagonal-only | On |
| **Min stars for 3×3** | Minimum stars required for full matrix | 15 |
| **Force 3×3** | Override condition number check | Off |
| **Regularization** | Ridge regression strength multiplier | 1.0 |

#### Understanding the Annulus

The background annulus is a ring-shaped region around each star used to measure local sky background:

```
        ┌─────────────────┐
        │    BG outer     │
        │   ┌─────────┐   │
        │   │BG inner │   │
        │   │  ┌───┐  │   │
        │   │  │ ★ │  │   │  ★ = Star (Aperture)
        │   │  └───┘  │   │  Inner ring = excluded zone
        │   └─────────┘   │  Outer ring = background sample area
        └─────────────────┘
```

- **Aperture**: Circle where star flux is measured (should contain most of the PSF)
- **BG inner**: Start of background ring (should be outside the star's light)
- **BG outer**: End of background ring (larger = more pixels for robust estimate)

#### When to Adjust

- **Crowded fields**: Reduce BG outer to avoid neighboring stars
- **Large star PSFs**: Increase Aperture and BG inner proportionally
- **Noisy images**: Increase SNR threshold to use only well-measured stars
- **Bright targets**: Lower Saturation threshold if stars are blooming

#### Matrix Mode Selection

The **full 3×3 matrix** accounts for cross-channel color contamination (e.g., red light leaking into the green channel), providing more accurate color correction for cameras with significant channel crosstalk. The **diagonal-only** mode applies independent scaling to each RGB channel, which is simpler and more numerically stable.

| Scenario | Recommended Mode |
|----------|-----------------|
| Most cameras (default) | Full 3×3 |
| Very few stars in field (<15) | Diagonal (auto-fallback) |
| Unstable/noisy calibration results | Try diagonal-only |
| OSC cameras with strong Bayer crosstalk | Full 3×3 |
| Mono camera with narrowband filters | Diagonal-only |

The algorithm automatically falls back to diagonal mode if:
- Fewer stars than the threshold pass quality filters
- The matrix condition number exceeds 50 (numerical instability)
- The least-squares solution fails

**Force 3×3 Option:**

If calibration keeps falling back to diagonal mode due to high condition number but you have plenty of stars, enable **Force 3×3** to override the condition number check and always use the full 3×3 matrix. This can provide better cross-channel correction for OSC cameras with correlated RGB channels, at the cost of potentially less stable results.

**Regularization Tuning:**

The **Regularization** control uses identity-regularized ridge regression: it penalizes deviation from the identity matrix rather than deviation from zero. This allows you to balance between maximum correction (low regularization) and preserving slope = 1.0 (high regularization).

| Regularization | Effect on Matrix | AFTER Plot Result |
|----------------|------------------|-------------------|
| 0.1-0.5 (low) | More cross-channel terms | Tighter scatter, slopes may deviate from 1.0 |
| 1.0 (default) | Balanced | Good scatter reduction with reasonable slopes |
| 10-50 (high) | Pushes toward identity | Slopes closer to 1.0, less scatter correction |
| 100+ (very high) | Nearly identity | Slopes ≈ 1.0, minimal correction |

If your AFTER plot shows tight scatter but slopes far from 1.0 (e.g., 0.5-0.7), increase regularization to 10-50 to push the matrix toward identity and improve slopes.

---

## Output

### Console Output
```
[SPCC] Combo selection - text: 'G2V', data: 'G2V'
[SPCC] White reference: G2V
[SPCC] Reference integrals: R=1234.5678, G=1456.7890, B=1123.4567
[SPCC] SEP detected 5000 sources (raw)
[SPCC] SEP after flux radius filter: 4500 sources

[SPCC] ===== STAR MATCHING SUMMARY =====
[SPCC] Catalog stars in field: 2000
[SPCC] SEP detections: 4500
[SPCC] Match radius: 5.0 pixels
[SPCC] Unique 1-to-1 matches: 1500
[SPCC] =====================================

[SPCC] Found 450/500 spectra in local DB
[SPCC] Downloading 50 spectra from Gaia archive in 1 batches...
[SPCC] Batch 1/1: Downloading 50 spectra...
[SPCC] Batch 1: Got 48 spectra
[SPCC] Downloaded 48 spectra total

[SPCC] ===== REJECTION SUMMARY =====
[SPCC] Total matched stars: 1500
[SPCC] Rejected - no XP spectrum: 1000
[SPCC] Rejected - negative flux: 5
[SPCC] Rejected - not centered: 20
[SPCC] Rejected - low SNR: 50
[SPCC] Rejected - saturated: 100
[SPCC] Rejected - color mismatch: 25
[SPCC] Stars passing all filters: 300
[SPCC] ================================

[SPCC] Matrix fit complete (full 3x3): used 285/300 stars
[SPCC] Color correction matrix A (maps measured → predicted):
       [+1.0234  -0.0156  +0.0089]   [R]   [R']
       [-0.0045  +1.0012  +0.0023] × [G] = [G']
       [+0.0067  -0.0134  +0.8456]   [B]   [B']
[SPCC] RMS residual: 0.0234
[SPCC] Diagonal elements: R=1.0234, G=1.0012, B=0.8456
```

### Diagnostic Plots

Two scatter plots are generated:

1. **BEFORE** - Measured ratio vs Expected ratio (pre-calibration)
2. **AFTER** - Corrected ratio vs Expected ratio (post-calibration)

Each plot shows:
- R/G ratios (red circles)
- B/G ratios (blue squares)
- Linear fit lines with slope (k), intercept (b), and scatter (s)
- Ideal y=x reference line
- White reference point at (1.0, 1.0)
- Solid points = used in fit, faded = sigma-clipped outliers

---

## Technical Implementation Details

### Lazy Loading
All optional dependencies are lazy-loaded to minimize startup time and avoid import errors:
```python
_lazy_cache = {}

def _get_sep():
    if 'sep' not in _lazy_cache:
        try:
            import sep
            _lazy_cache['sep'] = sep
        except ImportError:
            _lazy_cache['sep'] = None
    return _lazy_cache['sep']
```

### WCS Handling
Automatically extracts 2D celestial WCS from 3D data cubes:
```python
if self.wcs.naxis != 2:
    self.wcs = self.wcs.celestial  # Extract RA/Dec only
```

### 3×3 Matrix Fitting
Ridge regression with iterative outlier rejection:
```python
for ch in range(3):
    M_w = M[mask] * W_sqrt[:, np.newaxis]
    p_w = P[mask, ch] * W_sqrt
    MtM = M_w.T @ M_w
    Mtp = M_w.T @ p_w
    reg_matrix = regularization * np.eye(3)
    A_new[ch, :] = np.linalg.solve(MtM + reg_matrix, Mtp)
```

### Batch Downloading
XP spectra downloaded in batches of 50 to show progress and avoid timeouts:
```python
for batch_idx in range(0, len(missing_source_ids), batch_size):
    batch = missing_source_ids[batch_idx:batch_idx + batch_size]
    calibrated_df, sampling = gaiaxpy_calibrate(batch, sampling=xp_sampling_nm)
```

---

## Known Limitations

1. **Requires plate-solved image** - WCS must be present in image metadata
2. **Not for narrowband** - SPCC is designed for broadband RGB imaging
3. **Gaia magnitude limit** - Limited to stars brighter than ~G=16
4. **XP spectrum coverage** - Not all Gaia stars have XP spectra available
5. **Download speed** - First-time use requires downloading spectra (use local DB for speed)

---

## Troubleshooting

### "No WCS found"
Plate-solve your image first using astrometry tools (ASTAP, Astrometry.net, etc.)

### "WCS has N dimensions"
The script automatically extracts 2D celestial WCS from 3D cubes.

### "No XP spectra available"
- Enable "Use Local DB" if you have a populated database
- Ensure GaiaXPy is installed for online downloads
- Some fields may have few stars with XP spectra

### High condition number warning
The matrix fit switched to diagonal-only mode due to numerical instability. This usually happens with very few stars or highly correlated data.

### Poor calibration results
- Check that correct filter/sensor curves are selected
- Try increasing star limit
- Verify the white reference is appropriate for your target
- Check the diagnostic plots for outlier issues

---

## Version History

- **v1.0** - Initial implementation with diagonal matrix
- **v1.1** - Added lazy loading, fixed white reference selection bug (PyQt6 userData)
- **v1.2** - Implemented full 3×3 matrix fitting with ridge regression
- **v1.3** - Added batch downloading with progress (50 spectra per batch)
- **v1.4** - Improved diagnostic plots with proper linear fits (y = mx + b)
- **v1.5** - Added user controls for 3×3 vs diagonal matrix selection
- **v1.6** - Added "Force 3×3" checkbox and identity-regularization control for 3×3 matrix tuning

---

  ## References                                                                                               
  - PixInsight SPCC Documentation                                                                             
  - Gaia DR3 BP/RP Spectrophotometry 
